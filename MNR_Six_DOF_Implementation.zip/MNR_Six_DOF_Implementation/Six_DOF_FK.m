function T = Six_DOF_FK(q)
% =========================================================================
% Six_DOF_FKs
%
% Forward kinematics of a conventional 6-DOF serial robot manipulator
% using standard Denavit–Hartenberg (DH) parameters.
%
% INPUT:
%   q : 6x1 vector of joint angles [rad]
%
% OUTPUT:
%   T : 4x4 homogeneous transformation matrix of the end-effector
%       with respect to the base frame
%
% NOTE:
%   - All joint variables are assumed to be revolute.
%   - DH parameters follow the standard convention.
%   - This FK function is used by the MNR-based inverse kinematics example.
% =========================================================================


%% ------------------------------------------------------------------------
% Joint variables
% ------------------------------------------------------------------------
t1 = q(1);
t2 = q(2);
t3 = q(3);
t4 = q(4);
t5 = q(5);
t6 = q(6);


%% ------------------------------------------------------------------------
% Robot geometric parameters (link lengths in meters)
% ------------------------------------------------------------------------
L1 = 0.692;
L2 = 0.65;
L3 = 0.65;
L4 = 0.4545;


%% ------------------------------------------------------------------------
% DH parameters
% ------------------------------------------------------------------------
%    [theta_i   d_i    a_i   alpha_i]
d1 = L1;   a1 = 0;   alpha1 =  90;
d2 = 0;    a2 = L2;  alpha2 =   0;
d3 = 0;    a3 = 0;   alpha3 =  90;
d4 = L3;   a4 = 0;   alpha4 = -90;
d5 = 0;    a5 = 0;   alpha5 =  90;
d6 = L4;   a6 = 0;   alpha6 =   0;


%% ------------------------------------------------------------------------
% Individual homogeneous transformation matrices
% ------------------------------------------------------------------------

A1 = dh_matrix(t1, d1, a1, alpha1);
A2 = dh_matrix(t2, d2, a2, alpha2);
A3 = dh_matrix(t3, d3, a3, alpha3);
A4 = dh_matrix(t4, d4, a4, alpha4);
A5 = dh_matrix(t5, d5, a5, alpha5);
A6 = dh_matrix(t6, d6, a6, alpha6);


%% ------------------------------------------------------------------------
% End-effector transformation
% ------------------------------------------------------------------------
T = A1 * A2 * A3 * A4 * A5 * A6;

end


% =========================================================================
% Standard DH transformation matrix
% =========================================================================
function A = dh_matrix(theta, d, a, alpha)

A = [ cos(theta), -sin(theta)*cosd(alpha),  sin(theta)*sind(alpha), a*cos(theta);
      sin(theta),  cos(theta)*cosd(alpha), -cos(theta)*sind(alpha), a*sin(theta);
      0,           sind(alpha),             cosd(alpha),            d;
      0,           0,                      0,                       1 ];
end
